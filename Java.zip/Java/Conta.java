
package com.mycompany.mavenproject2;


public class Conta {
    
    private double saldo;
    
    Conta (){
        // Evidenciar o conta em vazio. (Obrigatoriamente deve-se declarar ao utilizar o método construtor. pela boa pratica)
    }
    
    Conta (double valor){
        creditar(valor);
    }
    
    public void debitar(double valor)
    {
        saldo = saldo - valor;
    }
    
    public void creditar(double valor)
    {
       saldo = saldo + valor;
    }
    
    public void transferir (Conta destino, double valor)
    {
        debitar(valor);
        destino.creditar(valor);
    }
    
    
    public String imprimir()
    {
        return "SALDO:" + saldo;
    }
    
    
}

